package bg.sofia.uni.fmi.mjt.markdown.models;

public record Markdown(String symbol, String regex) {
}
