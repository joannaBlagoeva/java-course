package bg.sofia.uni.fmi.mjt.markdown.models;

public record HtmlTags(String open, String close) {
}
